# homerental-backend
This repository contains the backend of homerental app I developed towards the successful completion of course CMPE-273 Enterprise Distributed Systems 
