const MONGO_DB_NAME="homeaway";
module.exports = {MONGO_DB_NAME};
